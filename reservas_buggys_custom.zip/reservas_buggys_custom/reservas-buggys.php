<?php
/*
Plugin Name: Reservas Buggys Custom
Description: Plugin personalizado para reservar buggys con control de personas por vehículo.
Version: 1.0
Author: Korpux
*/
// cargamos el handler del webhook
require_once plugin_dir_path(__FILE__) . 'includes/webhook-handler.php';


function mostrar_formulario_buggy_custom() {
  ob_start(); ?>
  <!--  Flatpickr  -->
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/flatpickr/dist/themes/material_green.css">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/flatpickr/dist/flatpickr.min.css">
  <script src="https://cdn.jsdelivr.net/npm/flatpickr"></script>
  <script src="https://cdn.jsdelivr.net/npm/flatpickr/dist/l10n/es.js"></script>

  <!--  CSS propio  -->
  <link rel="stylesheet" href="<?php echo plugin_dir_url(__FILE__) . 'assets/css/estilo.css'; ?>">

  <div class="formulario-contenedor">
    <form id="formulario-buggy" class="formulario-buggy" method="post">
      <!-- CABECERA -->
      <div class="form-header">
        <h2 class="titulo-principal">Ruta en buggy por la Sierra</h2>
        <img src="<?php echo plugin_dir_url(__FILE__) . 'assets/images/logo-world-adventures.webp'; ?>"
              alt="World Adventures" class="logo-reserva">
      </div>

      <div class="grupo-flex">
        <label>Nombre</label>
        <input type="text" name="nombre" required>
      </div>
      <div class="grupo-flex">
        <label>Apellido</label>
        <input type="text" name="apellido" required>
      </div>
      <div class="grupo-flex">
        <label>Email</label>
        <input type="email" name="email" required>
      </div>
      <div class="grupo-flex">
        <label>Teléfono</label>
        <input type="tel" name="telefono" required>
      </div>

      <!-- ¿ES UN REGALO? -->
      <div class="grupo-flex">
        <label><input type="checkbox" name="es_regalo"> ¿Es un regalo?</label>
      </div>

      <!-- FECHA -->
      <div class="grupo-flex">
        <label>Fecha de reserva</label>
        <input type="date" name="fecha" class="input-pequeño" required>
      </div>

      <!-- HORA -->
      <div class="grupo-flex horizontal">
        <label>Hora de reserva</label>
        <div class="radio-horas">
          <label><input type="radio" name="hora" value="10:00" required> 10:00 am (Debe llegar antes de las 9:30)</label>
          <label><input type="radio" name="hora" value="15:00"> 15:00 pm (Debe llegar antes de las 14:30)</label>
        </div>
      </div>

      <!-- VEHÍCULOS -->
      <div class="grupo-flex">
        <label>Vehículos disponibles: <span id="vehiculos-max">5</span>
          <img src="<?php echo plugin_dir_url(__FILE__) . 'assets/images/buggy-icon.png'; ?>" class="icono-buggy" alt="">
        </label>

        <input type="range" name="vehiculos" id="vehiculos"
              min="1" max="5" value="1" oninput="validarVehiculo(this)">

        <p class="info-seleccion">
          Vehículos seleccionados: <span id="vehiculos-seleccionados">1 buggy</span>
        </p>
      </div>

      <!-- TARJETAS -->
      <div id="cards-vehiculos" class="cards"></div>

      <button type="submit" name="reservar_buggy" class="btn-reservar">Reservar ahora</button>
    </form>
  </div>

  <script>
  document.addEventListener('DOMContentLoaded', () => {
    /* Calendario en español */
    flatpickr("input[name='fecha']", {
      dateFormat: "d/m/Y",
      minDate: "today",
      locale: "es"
    });

    const slider = document.getElementById('vehiculos');
    if (!slider) return;   /* estamos en otra página */

    /* ---------- Funciones globales ---------- */
    window.generarCards = function (cantidad) {
      const cont = document.getElementById('cards-vehiculos');
      cont.innerHTML = '';
      for (let i = 1; i <= cantidad; i++) {
        cont.innerHTML += `
          <div class="card">
            <h3>Buggy ${i}</h3>
            <div class="buggy-img-wrap">
              <img src="<?php echo plugin_dir_url(__FILE__) . 'assets/images/buggy-icon.png'; ?>" class="icono-buggy-grande" alt="Buggy">
            </div>
            <h4 class="label-personas">Número de personas:</h4>
            <div class="radio-personas">
              <label><input type="radio" name="personas_buggy_${i}" value="1" checked> 1</label>
              <label><input type="radio" name="personas_buggy_${i}" value="2"> 2</label>
            </div>
          </div>`;
      }
    };

    window.actualizarCantidad = function (valor) {
      const n   = parseInt(valor, 10);
      const txt = n === 1 ? '1 buggy' : `${n} buggys`;
      document.getElementById('vehiculos-seleccionados').textContent = txt;
    };

    window.validarVehiculo = function (sl) {
      const v = parseInt(sl.value, 10);
      if (v < 1) sl.value = 1;
      window.actualizarCantidad(sl.value);
      window.generarCards(sl.value);
    };

    /* Inicializar */
    window.validarVehiculo(slider);
  });
  </script>
  <?php
  return ob_get_clean();
}

/* ---------- Guarda en sesión y redirige ---------- */
function formulario_buggy_handle_post() {
  if (isset($_POST['reservar_buggy'])) {
    session_start();
    $_SESSION['buggy_reserva'] = [
      'nombre'    => sanitize_text_field($_POST['nombre'] ?? ''),
      'apellido'  => sanitize_text_field($_POST['apellido'] ?? ''),
      'email'     => sanitize_email($_POST['email'] ?? ''),
      'telefono'  => sanitize_text_field($_POST['telefono'] ?? ''),
      'fecha'     => sanitize_text_field($_POST['fecha'] ?? ''),
      'hora'      => sanitize_text_field($_POST['hora'] ?? ''),
      'vehiculos' => intval($_POST['vehiculos'] ?? 1),
      'personas'  => array_map('intval', $_POST['personas'] ?? []),
    ];
    wp_redirect(site_url('/checkout-buggys/'));
    exit;
  }
}
add_action('init', 'formulario_buggy_handle_post');

/* ---------- Shortcode que muestra el checkout ---------- */
function buggy_checkout_shortcode() {
  if ( ! session_id() ) {
      session_start();
  }
  if ( empty($_SESSION['buggy_reserva']) ) {
      return '<p>No hay ninguna reserva en curso.</p>';
  }
  $r = $_SESSION['buggy_reserva'];
  $precio_unitario = 120; 
  $total = $precio_unitario * $r['vehiculos'];

  ob_start(); ?>
  <link rel="stylesheet" href="<?php echo plugin_dir_url(__FILE__) . 'assets/css/estilo.css'; ?>">
  <div class="checkout-buggy-container">
    <h2 class="checkout-title">Esta es tu reserva</h2>
    <div class="checkout-header">
      <div class="checkout-info">
        <span><strong>Fecha:</strong> <?php echo esc_html($r['fecha']); ?></span>
        <span><strong>Hora:</strong> <?php echo esc_html($r['hora']); ?></span>
      </div>
      <div class="checkout-action">
            <form method="post" onsubmit="return confirm('¿Seguro que quieres borrar tu reserva?');">
        <button type="submit" name="clear_buggy_cart" class="btn-clear">
          <i class="dashicons dashicons-trash"></i>
        </button>
      </form>

      </div>
    </div>
    <div class="checkout-body">
      <div class="checkout-img">
        <img src="<?php echo plugin_dir_url(__FILE__) . 'assets/images/buggy-icon.png'; ?>" alt="Buggy" width="200" height="auto">
      </div>
      <div class="checkout-details">
        <ul>
          <li><strong>Ruta:</strong> Ruta en buggy por la Sierra</li>
          <li><strong>Vehículos:</strong> <?php echo intval($r['vehiculos']); ?></li>
          <?php if(!empty($r['personas'])): ?>
            <?php foreach($r['personas'] as $i=>$num): ?>
              <li><strong>Buggy <?php echo $i+1; ?>:</strong> <?php echo intval($num); ?> pers.</li>
            <?php endforeach; ?>
          <?php endif; ?>
        </ul>
        <div class="checkout-totals">
          <div><span>Precio unitario</span><span>€<?php echo number_format($precio_unitario,2); ?></span></div>
          <div><span>Subtotal</span><span>€<?php echo number_format($total,2); ?></span></div>
          <div class="total-line"><span>Total</span><span>€<?php echo number_format($total,2); ?></span></div>
        </div>
        <!-- Linea importantisima -->
        <form method="post" action="<?php echo site_url('/pago-buggy/'); ?>">
          <input type="hidden" name="monto" value="<?php echo esc_attr($total); ?>">
          <button type="submit" class="btn-reservar">Pagar tu reserva</button>
        </form>
      </div>
    </div>
  </div>
  <?php
  return ob_get_clean();
}

// 1) Handler para vaciar la sesión y redirigir
function clear_buggy_cart_handler() {
    if ( isset($_POST['clear_buggy_cart']) ) {
        if ( ! session_id() ) {
            session_start();
        }
        unset($_SESSION['buggy_reserva']);
        // Aquí pones la URL de la página donde está tu shortcode [formulario_buggy_custom]
        wp_redirect( site_url('/reservar/') ); 
        exit;
    }
}

add_shortcode('procesar_pago_stripe', 'procesar_pago_stripe_func');

function procesar_pago_stripe_func() {
    if ( ! session_id() ) {
        session_start();
    }

    if ( ! isset($_POST['monto']) ) {
        return '<p>Algo ha fallado con el pago.</p>';
    }

    require_once plugin_dir_path(__FILE__) . 'vendor/autoload.php';

    \Stripe\Stripe::setApiKey('sk_test_51RGfb3AT6xFDVnDPuL5ZjNmLeLUZdGeyHU378bXH72d04RgCMAynJQbazeYKEUm5qx3Uj2A66Te5njEBIZLRZDFB00wcyn29DL');

    try {
        $session = \Stripe\Checkout\Session::create([
            'payment_method_types' => ['card'],
            'line_items' => [[
                'price_data' => [
                    'currency' => 'eur',
                    'product_data' => [
                        'name' => 'Reserva Buggy',
                    ],
                    'unit_amount' => $_POST['monto'] * 100,
                ],
                'quantity' => 1,
            ]],
            'mode' => 'payment',
            'success_url' => site_url('/gracias/'),
            'cancel_url' => site_url('/checkout-buggys/'),
        ]);

        // Redirigir al checkout de Stripe
        wp_redirect($session->url);
        exit;

    } catch (\Exception $e) {
        return '<p>Error creando la sesión: ' . $e->getMessage() . '</p>';
    }
}

// … tu código de shortcodes y handlers anteriores …

/* ───────────── WEBHOOK STRIPE ───────────── */

add_action('init', 'clear_buggy_cart_handler');


add_shortcode('formulario_buggy_custom', 'mostrar_formulario_buggy_custom');
add_shortcode('buggy_checkout', 'buggy_checkout_shortcode');
?>
