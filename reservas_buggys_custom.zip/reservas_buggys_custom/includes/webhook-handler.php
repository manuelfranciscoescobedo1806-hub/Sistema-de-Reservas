<?php

    // Solo ejecutamos el webhook si la petición viene de Stripe (tiene la cabecera especial)
    if ($_SERVER['REQUEST_METHOD'] !== 'POST' || empty($_SERVER['HTTP_STRIPE_SIGNATURE'])) {
        return; // Salimos sin hacer nada, así no rompe el resto de WordPress
    }

    require_once __DIR__ . '/../vendor/autoload.php';

    \Stripe\Stripe::setApiKey('sk_test_51RGfb3AT6xFDVnDPuL5ZjNmLeLUZdGeyHU378bXH72d04RgCMAynJQbazeYKEUm5qx3Uj2A66Te5njEBIZLRZDFB00wcyn29DL');

    // Usa tu secreto real de webhook
    $endpoint_secret = 'whsec_UIaMwBAUa7AMEZpLnjlWtRmJopIfOT86';

    $payload = @file_get_contents('php://input');
    $sig_header = $_SERVER['HTTP_STRIPE_SIGNATURE'];
    $event = null;

    try {
        $event = \Stripe\Webhook::constructEvent(
            $payload, $sig_header, $endpoint_secret
        );
    } catch (\UnexpectedValueException $e) {
        http_response_code(400);
        exit();
    } catch (\Stripe\Exception\SignatureVerificationException $e) {
        http_response_code(400);
        exit();
    }

    // Aqui vamos a manejar el evento payment_intent.succeeded que nos proporciona stripe

    if ($event->type === 'payment_intent.succeeded') {
        session_start();
        $reserva = $_SESSION['buggy_reserva'] ?? null;
    
        if ($reserva) {
            // Construir el JSON
            $data = [
                'name' => $reserva['nombre'],
                'last_name' => $reserva['apellido'],
                'email' => $reserva['email'],
                'phone' => $reserva['telefono'],
                'item' => [
                    [
                        'name_vehicle' => 'Buggy',
                        'price' => 120,
                        'quantity' => $reserva['vehiculos'],
                        'guest' => array_sum($reserva['personas']),
                        'total' => 120 * $reserva['vehiculos'],
                    ]
                ],
                'day' => $reserva['fecha'],
                'time' => $reserva['hora'],
                'total' => 120 * $reserva['vehiculos'],
            ];
    
            // Enviar a la API REST
            $api_url = 'https://tu-api.com/endpoint'; // Cambia esto por la URL de tu API
            $response = wp_remote_post($api_url, [
                'body' => json_encode($data),
                'headers' => [
                    'Content-Type' => 'application/json',
                ],
            ]);
    
            if (is_wp_error($response)) {
                error_log('Error enviando datos a la API: ' . $response->get_error_message());
            } else {
                error_log('Datos enviados a la API correctamente');
            }
    
            // Opcional: Limpiar la sesión tras el éxito
            unset($_SESSION['buggy_reserva']);
        }
    }

    http_response_code(200);
    echo 'Webhook recibido correctamente';
    exit;

