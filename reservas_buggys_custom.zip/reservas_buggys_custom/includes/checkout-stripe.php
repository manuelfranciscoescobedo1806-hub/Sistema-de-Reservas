<?php
    require_once __DIR__ . '/../vendor/autoload.php';
    \Stripe\Stripe::setApiKey('sk_test_51RGiEM4FiguJX0uDcNQT5ihaLNYXZqdbtjX5HbAQmIWSUPUJBr5VmJ1d3nklz3UkLVw5qe35mmrK3KEt9WmaUnXC00EnuobPHh'); // ⚠️ Usa tu clave secreta

    session_start();

    if (empty($_SESSION['buggy_reserva'])) {
    wp_redirect(site_url('/reservar/'));
    exit;
    }

    $r = $_SESSION['buggy_reserva'];
    $precio_unitario = 12000; // en céntimos = €120
    $total = $precio_unitario * $r['vehiculos'];

    // Crear sesión de pago
    $session = \Stripe\Checkout\Session::create([
    'payment_method_types' => ['card'],
    'line_items' => [[
        'price_data' => [
        'currency' => 'eur',
        'product_data' => [
            'name' => 'Reserva en buggy - ' . $r['fecha'],
        ],
        'unit_amount' => $precio_unitario,
        ],
        'quantity' => $r['vehiculos'],
    ]],
    'mode' => 'payment',
    'success_url' => site_url('/reserva-exitosa/') . '?session_id={CHECKOUT_SESSION_ID}',
    'cancel_url' => site_url('/checkout-buggys/'),
    'metadata' => [
        'fecha' => $r['fecha'],
        'hora' => $r['hora'],
    ],
    ]);

    wp_redirect($session->url);
    exit;


